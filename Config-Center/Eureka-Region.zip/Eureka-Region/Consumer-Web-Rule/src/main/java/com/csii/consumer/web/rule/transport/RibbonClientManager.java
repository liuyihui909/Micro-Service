package com.csii.consumer.web.rule.transport;

import com.netflix.appinfo.ApplicationInfoManager;
import com.netflix.appinfo.EurekaInstanceConfig;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.appinfo.MyDataCenterInstanceConfig;
import com.netflix.appinfo.providers.EurekaConfigBasedInstanceInfoProvider;
import com.netflix.client.ClientFactory;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DeploymentContext;
import com.netflix.discovery.DefaultEurekaClientConfig;
import com.netflix.discovery.DiscoveryClient;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.EurekaClientConfig;
import com.netflix.loadbalancer.Server;
import com.netflix.loadbalancer.ZoneAwareLoadBalancer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.commons.util.InetUtilsProperties;

import java.io.IOException;
import java.util.Map;


public class RibbonClientManager implements InitializingBean, DisposableBean {

    public static final String RIBBON_CONFIG_FILE_NAME = "ribbon-client.properties";
    private static final Logger logger = LoggerFactory.getLogger(RibbonClientManager.class);
    private static ApplicationInfoManager applicationInfoManager;
    private static EurekaClient eurekaClient;
    private static InetUtils inetUtils = new InetUtils(new InetUtilsProperties());

    private static synchronized ApplicationInfoManager initializeApplicationInfoManager(
            EurekaInstanceConfig instanceConfig) {
        if (applicationInfoManager == null) {
            InstanceInfo instanceInfo = new EurekaConfigBasedInstanceInfoProvider(instanceConfig).get();
            applicationInfoManager = new ApplicationInfoManager(instanceConfig, instanceInfo);
        }

        return applicationInfoManager;
    }

    private static synchronized EurekaClient initializeEurekaClient(
            ApplicationInfoManager applicationInfoManager, EurekaClientConfig clientConfig) {
        if (eurekaClient == null) {
            eurekaClient = new DiscoveryClient(applicationInfoManager, clientConfig);
        }

        return eurekaClient;
    }

    private static synchronized void initializeRibbonClient() throws Exception {
        logger.info("开始初始化ribbon");
        try {
            ConfigurationManager.loadPropertiesFromResources(RIBBON_CONFIG_FILE_NAME);
        } catch (IOException e) {
            logger.error("ribbon初始化失败");
            throw new IllegalStateException("ribbon初始化失败");
        }
    }

    private static synchronized void init() throws Exception {
        ApplicationInfoManager applicationInfoManager =
                initializeApplicationInfoManager(new ServiceDataCenterInstanceConfig(inetUtils));
        initializeEurekaClient(applicationInfoManager, new ServiceEurekaClientConfig());

        initializeRibbonClient();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        init();
    }

    @Override
    public void destroy() throws Exception {
        if (eurekaClient != null) {
            eurekaClient.shutdown();
        }
    }

    /**
     * 根据服务实例获取服务地址.
     *
     * @param serviceName 服务实例
     * @return 服务地址
     */
    public String getServiceAddress(String serviceName) {
        ZoneAwareLoadBalancer lb =
                (ZoneAwareLoadBalancer) ClientFactory.getNamedLoadBalancer(serviceName);
        Server selected = lb.chooseServer("default");
        //Server selected = chooseRule.choose(lb);
        if (null == selected) {
            logger.warn("服务{}没有可用地址", serviceName);
            return null;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("http://").append(selected.getHostPort());
        return sb.toString();
    }

    private static class ServiceDataCenterInstanceConfig extends MyDataCenterInstanceConfig {
        InetUtils.HostInfo hostInfo;

        public ServiceDataCenterInstanceConfig(InetUtils inetUtils) {
            super();
            this.hostInfo = inetUtils.findFirstNonLoopbackHostInfo();
        }

        @Override
        public String getHostName(boolean refresh) {
            return hostInfo.getHostname();
        }

        @Override
        public String getIpAddress() {
            return hostInfo.getIpAddress();
        }

        @Override
        public String getInstanceId() {
            String appName = this.getAppname() == null ? "" : this.getAppname();
            String zone = this.getMetadataMap().get("zone") == null ? "" : this.getMetadataMap().get("zone");
            return appName + "|" + zone + ":" + this.getIpAddress();
        }

        @Override
        public Map<String, String> getMetadataMap() {
            Map<String, String> metadataMap = super.getMetadataMap();
            String zone = metadataMap.get("zone");
            if (zone == null || "".equals(zone)) {
                String systemZone = System.getenv("eureka.metadata.zone");
                String contextZone = ConfigurationManager.getDeploymentContext().getValue(DeploymentContext.ContextKey.zone);
                String systemContextZone = System.getenv("@zone");
                zone = (contextZone != null && !"".equals(contextZone)) ? contextZone :
                        (systemContextZone != null && !"".equals(systemContextZone)) ? systemContextZone :
                                (systemZone != null && !"".equals(systemZone)) ? systemZone : zone;
            }
            metadataMap.put("zone", zone);
            return metadataMap;
        }
    }

    private static class ServiceEurekaClientConfig extends DefaultEurekaClientConfig {
        @Override
        public String[] getAvailabilityZones(String region) {
            String[] availabilityZones = super.getAvailabilityZones(region);
            if (availabilityZones == null) {
                String property = System.getenv("eureka." + region + ".availabilityZones");
                availabilityZones = property != null ? property.split(",") : DEFAULT_ZONE.split(",");
            }
            return availabilityZones;
        }
    }
}
