package com.csii.consumer.test;

import org.apache.tomcat.util.http.fileupload.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileLength {
    public static void main(String[] args) throws IOException {
        File file = new File("D:\\test\\外贸双章(1).zip");
        FileInputStream fis = new FileInputStream(file);
        int b = -1;
        int i = 0;
        while ((b = fis.read()) != -1) {
            i++;
        }
        System.out.println(i);
    }
}
