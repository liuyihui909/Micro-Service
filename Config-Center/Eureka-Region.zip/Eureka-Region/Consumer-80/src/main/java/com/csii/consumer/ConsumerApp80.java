package com.csii.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.commons.util.InetUtilsProperties;

@SpringBootApplication
@EnableDiscoveryClient
public class ConsumerApp80 {
    public static void main(String[] args) {
        InetUtils inetUtils = new InetUtils(new InetUtilsProperties());
        InetUtils.HostInfo hostInfo = inetUtils.findFirstNonLoopbackHostInfo();
//        SpringApplication.run(ConsumerApp80.class, args);
    }
}
