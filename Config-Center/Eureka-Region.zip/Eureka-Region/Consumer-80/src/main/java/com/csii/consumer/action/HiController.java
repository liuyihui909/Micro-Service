package com.csii.consumer.action;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLOutput;
import java.util.Arrays;

@RestController
public class HiController {
    private final RestTemplate restTemplate;

    @Value("${M2_HOME}")
    private String m2Home;

    public HiController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @RequestMapping(value="/consumer")
    public String hi() {
        return restTemplate.getForObject("http://provider/hi", String.class);
    }

    @RequestMapping(value = "/var")
    public String var(){
        return m2Home;
    }

    public static void main(String[] args) throws UnsupportedEncodingException {
        String str="·";
        String str1 = "·";
        byte[] chars = new byte[1];
        chars[0] = (byte) '•';
        String str3 = new String("•".getBytes(),0,"•".getBytes().length, StandardCharsets.UTF_8);
        System.out.println(str3);
        System.out.println(Arrays.toString(str3.getBytes()));
        String str2 = new String(str3.getBytes(), 0, str3.getBytes().length, "GBK");
        System.out.println(str2);
//        System.out.println((byte) 'a');
//        System.out.println((byte) 'A');
//        System.out.println(str.getBytes()[0]);
//        System.out.println(str1.getBytes()[0]);
//        System.out.println(str2.getBytes()[0]);
        System.out.println(new String(str2.getBytes(), 0, str3.getBytes().length, StandardCharsets.UTF_8));
//        System.out.println(str.equals(str1));
    }
}