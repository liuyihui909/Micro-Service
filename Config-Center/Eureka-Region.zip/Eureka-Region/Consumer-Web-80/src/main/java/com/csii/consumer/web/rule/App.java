package com.csii.consumer.web.rule;

public class App {
}
