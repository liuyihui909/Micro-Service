package com.csii.consumer.web.rule.action;

import com.csii.consumer.web.rule.transport.RibbonClientManager;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DispatcherAction {

    private final RibbonClientManager ribbonClientManager;

    public DispatcherAction(RibbonClientManager ribbonClientManager) {
        this.ribbonClientManager = ribbonClientManager;
    }

    @RequestMapping("/hi")
    public String hi() {
        ribbonClientManager.getServiceAddress("provider");
        return "index.jsp";
    }

}
